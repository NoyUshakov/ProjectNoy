using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectNoy.Pages
{
    public class registerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
